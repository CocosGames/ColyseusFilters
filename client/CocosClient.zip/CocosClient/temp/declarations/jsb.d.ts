/// <reference path="C:\CocosDashboard_1.0.20\resources\.editors\Creator\3.6.2\resources\resources\3d\engine\@types\jsb.d.ts"/>
