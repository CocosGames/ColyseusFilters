import {_decorator, Component, Node, NodeEventType, Sprite, SpriteFrame} from 'cc';
import Colyseus from 'db://colyseus-sdk/colyseus.js';

const {ccclass, property} = _decorator;

@ccclass('Main')
export class Main extends Component {
    @property hostname = "localhost";
    @property port = 2567;
    @property useSSL = false;

    client!: Colyseus.Client;
    room!: Colyseus.Room;

    @property(Node) big;
    @property(Node) small;
    @property(Node) selected;
    @property(Node) win;
    @property(Node) lose;
    @property(Node) bowl;
    @property([SpriteFrame]) nums:SpriteFrame[] = [];
    @property(Sprite) dice;

    start() {
        // Instantiate Colyseus Client
        // connects into (ws|wss)://hostname[:port]
        this.client = new Colyseus.Client(`${this.useSSL ? "wss" : "ws"}://${this.hostname}${([443, 80].includes(this.port) || this.useSSL) ? "" : `:${this.port}`}`);

        // Connect into the room
        this.connect();

        this.big.on(Node.EventType.MOUSE_DOWN, this.onBigSelected, this);
        this.small.on(Node.EventType.MOUSE_DOWN, this.onSmallSelected, this);
    }

    onBigSelected(event: MouseEvent) {
        if (this.room.state.status == "guessing") {
            this.selected.getComponent(Sprite).enabled = true;
            this.selected.position = this.big.position;
            this.room.send("guess", "+");
        }
    }

    onSmallSelected(event: MouseEvent) {
        if (this.room.state.status == "guessing") {
            this.selected.getComponent(Sprite).enabled = true;
            this.selected.position = this.small.position;
            this.room.send("guess", "-");
        }
    }

    async connect() {
        try {
            this.room = await this.client.joinOrCreate("my_room", {mode: "single"});

            console.log("joined successfully!");
            console.log("user's sessionId:", this.room.sessionId);

            this.room.onStateChange((state) => {
                console.log("onStateChange: ", state);
                if (state.status == "opened")
                {
                    this.bowl.getComponent(Sprite).enabled = false;
                    this.dice.spriteFrame = this.nums[state.number-1];
                    if (state.result=="win")
                    {
                        this.win.getComponent(Sprite).enabled = true;
                    }
                    else
                    {
                        this.lose.getComponent(Sprite).enabled = true;
                    }
                }
            });

            this.room.onLeave((code) => {
                console.log("onLeave:", code);
            });

        } catch (e) {
            console.error(e);
        }
    }
}

